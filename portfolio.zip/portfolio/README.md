# Portfolio

A simple 'Portfolio' application built using Django on the backend and on the front-end the template "Start Bootstrap Clean Blog".

This is the first of the three practical projects of the course course-django-2-practice-development-web-python-3 by [Hector Costa](https://www.hektorprofe.net/).

### Run project
You only need a virtualenv with `python 3.6.0` and `django 2.0`
